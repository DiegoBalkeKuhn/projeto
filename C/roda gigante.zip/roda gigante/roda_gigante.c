#include <stdio.h>
#include <stdlib.h>
#include "roda_gigante.h"



int main() {
    int opcao = -1;
    int capacidade = 0, quantidade = 0, fila = 0, pos_inicial = 1;

    rodaGigante_t *roda = criarRodaGigante();

    printf("--- Configuração da Roda Gigante ---\n");
    printf("Digite a capacidade de pessoas por carrinho: ");
    scanf("%d", &capacidade);
    printf("Digite a quantidade de carrinhos na roda: ");
    scanf("%d", &quantidade);
    printf("Digite a quantidade inicial de pessoas na fila: ");
    scanf("%d", &fila);
    
    for (int i = 0; i < quantidade; i++) {
        adicionarCarrinho(roda, capacidade);
    }
    roda->pessoasFila = fila;
    
    // Define o carrinho inicial
    roda->atual = roda->inicio;
    if (roda->atual) {
       printf("\nRoda gigante configurada com %d carrinhos. O carrinho atual é o de ID %d.\n", roda->qtdCarrinhos, roda->atual->id);
    } else {
       printf("\nRoda gigante criada sem carrinhos.\n");
    }

    while (opcao != 0) {
        printf("\n--- Painel de Controle ---\n");
        printf("Carrinho atual: %d | Pessoas na Fila: %d | Total Atendidas: %d\n", roda->atual ? roda->atual->id : 0, roda->pessoasFila, roda->totalAtendidas);
        printf("1. Avançar para o próximo carrinho\n");
        printf("2. Embarcar pessoas no carrinho atual\n");
        printf("3. Desembarcar pessoas do carrinho atual\n");
        printf("4. Realizar um giro completo (contabiliza voltas)\n");
        printf("5. Ir para um carrinho específico\n");
        printf("6. Exibir relatório completo\n");
        printf("0. Encerrar simulação\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                avancar(roda);
                break;
            case 2:
                embarcar(roda);
                break;
            case 3:
                desembarcar(roda);
                break;
            case 4:
                giroCompleto(roda);
                break;
            case 5:
                escolherCarrinho(roda);
                break;
            case 6:
                relatorio(roda);
                break;
            case 0:
                printf("Encerrando a simulação...\n");
                break;
            default:
                printf("Opção inválida! Tente novamente.\n");
                break;
        }
    }

    liberarMemoria(roda);

    return 0;
}
